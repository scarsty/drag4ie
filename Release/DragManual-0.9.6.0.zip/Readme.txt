﻿Super Drag and Go (Beta) for IE9
超级拖拽(beta) for IE 9

Author: s.weyl
Version: 0.9.5.0 (beta)


If you know what "Super Drag and Go" is, you might need it. For more information or source code, please contact with me by e-mail (scarsty@gmail.com).


1. How to install and uninstall:

First of all, please make sure you have .NET Framework 4.0. You can get it from http://www.microsoft.com/downloads/en/details.aspx?familyid=9cfb2d51-5ff4-4491-b0e5-b386f32c0992.

Manually:

To install, you have to decompress the ZIP file into any directory, then run "install.cmd" as Administrator. If you want to use it in 64 bit IE, please run "install64.cmd"

Similarly, to uninstall, just do the same but run "uninstall.cmd", which will remove both 32 and 64 bit versions.

You can also use "CustomDrag.exe" to modify the behavior of this BHO, or add a link of this program into IE tools menu. All settings will be deleted when uninstall.

Automatically:

Also you can use the msi file to install it automatically, but now it only supports 32 bit IE. Then you have to use "Control Panel" to uninstall it.

Hope you can like it.


2. The "Search string":

Please search "{0}" in the engineering you prefer, then just copy the string in the address bar.

But you have to note, if there are not "{0}" in the string, but "%7B0%7D" instead, please change "%7B0%7D" to "{0}", then use it as "Search string".

3. References:

http://www.cnblogs.com/TianFang/archive/2011/03/12/1982100.html
http://www.codeproject.com/KB/cs/Issuewithbandobjects.aspx
Contents on MSDN.
And so on, many thanks to them.

Seek setup files in:
http://code.google.com/p/cs-drag4ie9/downloads/list
